<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateJobsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('jobs', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('titulo', 45);
			$table->text('descricao');
			$table->string('nivel_conhecimento_necessario', 45);
			$table->string('status', 45);
			$table->timestamps();
			$table->integer('empresa_id')->unsigned();
			$table->integer('projeto_id')->unsigned();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('jobs');
	}

}
