<?php

namespace App;

class Item extends Model
{
}