<?php

namespace App\Http\Controllers\Web\Empresa\Pesquisa;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function returnMessage( String $response, String $message )
    {
    	return array(
          'response' => $response,
          'message' => $message
      );
    }
}
